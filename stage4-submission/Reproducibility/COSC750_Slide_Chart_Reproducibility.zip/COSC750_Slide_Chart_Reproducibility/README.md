
# COSC 750 Stage 4 — Slide-Chart Reproducibility

Regenerates **seven numerical charts** corresponding to presentation slides **6–12**.

This is an independent chart-rendering package, **not a claim of pixel-identical reconstruction of the original embedded PNGs**. The existing PowerPoint has not been edited.

## Usage

```bash
python -m pip install numpy matplotlib
python regenerate_slide_charts.py
```

Outputs are in `charts/` and correspond to `slide06_...png` through `slide12_...png`.

## Provenance

- `figure_data_weights.csv` and the other two `figure_data_*.csv` files are preserved unchanged from the verified Stage 4 Overleaf source ZIP. The weighting CSV supplies the five matched-seed values for slide 9. `figure_data_threshold.csv` and `figure_data_paired.csv` are retained as source evidence for threshold and paired analyses.
- `slide06_main_cost.csv`: manuscript Table 4 (1% prevalence) and analytical always-alert baseline.
- `slide07_prevalence.csv`: manuscript Table 4, five prevalence levels.
- `slide08_threshold_means.csv`: manuscript Table 6 (means).
- `slide10_paired_ci.csv`: manuscript Section 8 (paired difference, unadjusted confidence interval, raw and adjusted p-values).
- `slide11_pca.csv`: manuscript Section 9 and supplementary Table 9. Slide 11's Brier numbers (0.3004 and 0.2508) are text annotations, not part of its PCA chart.
- `slide12_family_recall.csv`: manuscript Table 5.

All manually transcribed CSVs are **derived summaries of reported project tables**, not original experiment outputs.

The script uses the saved numerical data and does **not** train models, re-evaluate network traffic, regenerate the slide design, or independently verify the complete machine-learning experiment.

The paper's Figures 2–4 have a separate regeneration script (`regenerate_figures.py`).

## GitHub Repository and Version Identification

This chart-reproduction package is included in the COSC 750 Stage 4 submission under:

`stage4-submission/Reproducibility/COSC750_Slide_Chart_Reproducibility.zip`

The complete submission is maintained on the repository's `main` branch and identified by the `final` Git tag.

The historical core experimental verification commit (`916fe15836e10ceb8d0fb2c69d1e65cb49370ce6`) remains accessible under the `stage4-core-verified` tag.

The chart-regeneration package provides reproducible visualizations from saved numerical inputs. It does not replace the separately documented experimental verification procedures.
