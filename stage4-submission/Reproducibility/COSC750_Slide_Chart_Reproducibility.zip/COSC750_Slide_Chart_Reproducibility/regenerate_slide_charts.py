"""Regenerate seven data charts for COSC 750 Stage 4 slides 6–12.
Uses saved project CSVs and explicitly transcribed manuscript tables, NOT model retraining.
Run: python regenerate_slide_charts.py
"""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; OUT=ROOT/'charts'; OUT.mkdir(exist_ok=True)
BG='#101b35'; BLUE='#38b5eb'; TEAL='#27c8b8'; GRAY='#9baac4'; WHITE='#f1f5fb'

def read(name):
    with (DATA/name).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def style(ax):
    ax.set_facecolor(BG); ax.figure.patch.set_facecolor(BG)
    ax.tick_params(colors=WHITE,labelsize=10)
    for s in ax.spines.values():s.set_color('#6d7d95')
    ax.xaxis.label.set_color(WHITE);ax.yaxis.label.set_color(WHITE)
    ax.grid(axis='y',alpha=.12,color=WHITE);ax.set_axisbelow(True)
def save(fig,name):
    fig.savefig(OUT/name,dpi=190,bbox_inches='tight',facecolor=BG)
    plt.close(fig)

# Slide 6: cost comparison
r=read('slide06_main_cost.csv'); vals=[float(v['mean_cost']) for v in r]
assert np.allclose(vals,[.9561,.5989,.99],atol=1e-8)
fig,ax=plt.subplots(figsize=(9,4.3));style(ax)
y=np.arange(3);ax.barh(y,vals,color=[BLUE,TEAL,GRAY],height=.48)
ax.set_yticks(y,[v['model'] for v in r]);ax.invert_yaxis();ax.set_xlim(0,1.12)
ax.set_xlabel('Friday expected cost (lower is better)');ax.grid(axis='x',alpha=.12);ax.grid(axis='y',visible=False)
for i,v in enumerate(vals):ax.text(v+.02,i,f'{v:.3f}',color=WHITE,va='center',weight='bold')
save(fig,'slide06_main_cost.png')

# Slide 7: prevalence sensitivity
r=read('slide07_prevalence.csv');x=np.arange(len(r));fig,ax=plt.subplots(figsize=(9,4.3));style(ax)
for shift,key,color,label in [(-.24,'gaussian',BLUE,'Gaussian Bayes'),(0,'svm',TEAL,'RBF-SVM'),(.24,'best_constant',GRAY,'Best constant')]:
    ax.bar(x+shift,[float(v[key]) for v in r],width=.23,color=color,label=label)
ax.set_xticks(x,[f"{v['prevalence_pct']}%" for v in r]);ax.set_ylabel('Expected cost (lower is better)');ax.set_xlabel('Assumed attack prevalence');ax.legend(facecolor=BG,labelcolor=WHITE,fontsize=9)
save(fig,'slide07_prevalence.png')

# Slide 8: threshold ablation (saved 5-seed means)
r=read('slide08_threshold_means.csv');x=np.arange(2);fig,ax=plt.subplots(figsize=(9,4.3));style(ax)
for shift,key,color,label in [(-.24,'fixed_0_5',GRAY,'Fixed 0.5'),(0,'bayes_cost_threshold',BLUE,'Cost rule'),(.24,'thursday_optimized',TEAL,'Thursday tuned')]:
    ax.bar(x+shift,[float(v[key]) for v in r],width=.23,color=color,label=label)
ax.set_xticks(x,[v['model'] for v in r]);ax.set_ylabel('Friday expected cost');ax.set_ylim(0,1.14);ax.legend(facecolor=BG,labelcolor=WHITE)
save(fig,'slide08_threshold_ablation.png')

# Slide 9: weight ablation (original five-seed CSV; average)
r=read('figure_data_weights.csv');a={key:np.mean([float(v['expected_cost']) for v in r if v['variant']==key]) for key in ('unweighted','weighted_1_100')}
assert np.isclose(a['weighted_1_100'],.5989241,atol=1e-5)
fig,ax=plt.subplots(figsize=(8,4.3));style(ax)
vals=[a['unweighted'],a['weighted_1_100']];ax.bar(['SVM unweighted','SVM 1:100 weighted'],vals,color=[TEAL,BLUE],width=.48)
ax.set_ylim(0,.8);ax.set_ylabel('Friday expected cost')
for i,v in enumerate(vals):ax.text(i,v+.015,f'{v:.3f}',color=WHITE,ha='center',weight='bold',fontsize=13)
save(fig,'slide09_class_weight.png')

# Slide 10: unadjusted 95% paired CI and adjusted p
r=read('slide10_paired_ci.csv')[0];m=float(r['mean_difference']);lo=float(r['ci_low']);hi=float(r['ci_high'])
fig,ax=plt.subplots(figsize=(9,3.8));style(ax);ax.axvline(0,color=GRAY,linestyle='--')
ax.errorbar([m],[0],xerr=[[m-lo],[hi-m]],fmt='o',color=TEAL,ecolor=TEAL,capsize=7,markersize=10,lw=2)
ax.set_yticks([]);ax.set_xlim(-.1,.82);ax.set_ylim(-.6,.6);ax.set_xlabel('Paired cost difference: Gaussian − SVM')
ax.text(m,.19,f'{m:.3f}  [{lo:.3f}, {hi:.3f}]',color=WHITE,ha='center',weight='bold',fontsize=13)
ax.text(.02,-.38,f"Raw p = {float(r['raw_p']):.3f}     Bonferroni-adjusted p = {float(r['bonferroni_p']):.3f}",color=WHITE,fontsize=11)
save(fig,'slide10_uncertainty.png')

# Slide 11: PCA dimensions (Friday Brier values are text, not plotted)
r=read('slide11_pca.csv');fig,ax=plt.subplots(figsize=(9,4.3));style(ax)
xx=[int(v['dimensions']) for v in r]
for key,color,label in [('gaussian',BLUE,'Gaussian'),('svm',TEAL,'SVM')]:
    ax.plot(xx,[float(v[key]) for v in r],'-o',color=color,label=label,lw=2.4)
ax.set_xticks(xx);ax.set_xlabel('PCA dimensions');ax.set_ylabel('Mean Friday cost');ax.set_ylim(.48,1.16);ax.legend(facecolor=BG,labelcolor=WHITE)
save(fig,'slide11_pca_sensitivity.png')

# Slide 12: unseen attack-family recall
r=read('slide12_family_recall.csv');x=np.arange(len(r));fig,ax=plt.subplots(figsize=(9,4.3));style(ax)
ax.bar(x-.17,[float(v['gaussian_pct']) for v in r],width=.34,color=BLUE,label='Gaussian Bayes')
ax.bar(x+.17,[float(v['svm_pct']) for v in r],width=.34,color=TEAL,label='RBF-SVM')
ax.set_xticks(x,[v['family'] for v in r]);ax.set_ylabel('Friday recall (%)');ax.set_ylim(0,85);ax.legend(facecolor=BG,labelcolor=WHITE)
save(fig,'slide12_unseen_family_recall.png')
print('Generated:',*[p.name for p in sorted(OUT.glob('*.png'))],sep='\n  ')
